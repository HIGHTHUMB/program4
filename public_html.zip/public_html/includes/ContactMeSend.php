<!-- ***********************************************************************************
  Page Name  : Contact Confirmation Page 
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Page that displays a message stating that the email has been submitted after hitting the submit button

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->

 
<div align="center">
  <center>
  <table  cellpadding="0" cellspacing="0" width="75%" height="250" >
    <tr>
      <td width="75%" height="57"  colspan="8">
        <p align="center" style="font-size: 18px; margin-top: 50px;">
         <b>Your message has been submitted to email </b><br><br>
         <b>Thank you</b>
        </p>
      </td>
    </tr>
  </table>
  </center>
</div>




