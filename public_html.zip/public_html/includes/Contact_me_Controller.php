<!-- ***********************************************************************************
  Page Name  : Contact Me Controller
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Backend for Contact_me.php. Sends an email with all the variables from front end.

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->


<?php 

 if ( $_POST['Clear'] )
       {
          include('clear.php');
          include('Contact_me.php');

       }


else if(isset($_POST['submit'])) 
{ 
    $to           = "email"; 
    $lastname     = $_POST['LastName']; 
    $firstname    = $_POST['FirstName']; 
    $email        = $_POST['Email'];  
    $Genre        = $_POST['Genre'];
    $Type         = $_POST['Type'];
    $age          = $_POST['Age']; 
    $message      = $_POST['Comments']; 
    
    


    $body = "Your Email     $email\nLast Name     $lastname\nFirst Name     $firstname\n\nGenre             $Genre\nGame Type  "; foreach ($Type as $type) {    $body .= "  $type  ";}$body .= "\n\nAge                 $age\n\nComments:     $message\n";

                      

    mail($to, $subject, $body); 
    
    include('Jurdi_header.php');
    include('mainMenu.php');
    include('ContactMeSend.php');
    
} 
else 
{ 
   include('Jurdi_header.php');
   include('mainMenu.php');
   include('ContactMeSend.php');
   
   


}
 
?> 

