<!-- ***********************************************************************************
  Page Name  : Program 3 Page 
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Program 3 Page that includes 3 php files, contains a table with text inputs, radio buttons, submit buttons, and passes data to controller.

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<!DOCTYPE html>
<html>

  <head>
<title>JurdiHythamProgram3</title>
</head>

<body>
<header>
   


    <?php include ( 'Jurdi_header.php' ); ?>
    <td>&nbsp;</td> <!--Empty Row-->
    <?php include ( 'mainMenu.php' ); ?>
    <td>&nbsp;</td> <!--Empty Row-->
    
 
      <form method="post" action="Controller3.php">
        <table style="width: 50%; margin: 0px auto; padding-right: 10%;">
          <!--  text type input  -->
          <tr>
            <td style="width: 5%; text-align: right;">Telephone&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="Telephone" value="<?php echo $Telephone ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">Email&nbsp;</td>
            <td style="width: 20%;">
              <input id="birth" type="text" name="Email" value="<?php echo $Email ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">Last Name&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="LastName" value="<?php echo $LastName ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">First Name&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="FirstName" value="<?php echo $FirstName ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">Address&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="Address" value="<?php echo $Address ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">City&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="City" value="<?php echo $City ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">State&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="State" value="<?php echo $State ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">Country&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="Country" value="<?php echo $Country ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">Zip&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="Zip" value="<?php echo $Zip ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td> <!--Empty Row-->
          </tr>
          <!--  textarea box  -->
          <tr>
            <td style="width: 7%; text-align:right;">Comments &nbsp;</td>
            <td style="width: 20%;"> 
            <textarea name="Comments" style="width: 99%;" rows="5" cols="35"><?php echo $Comments;?></textarea></td>
          </tr>
          <td>&nbsp;</td> <!--Empty Row-->
          <!--  dropdown boxes -->
          <tr>
            <td style="width: 5%; text-align: right;">Age&nbsp;</td>
            <td style="width: 20%; text-align: left;">
              <select name="Age" style="width: 100%" size="1" ;>
                <option value="Under_20" <?php if ($Age == "Under_20") echo selected ?>>Under 20 </option>
                <option value="20-30" <?php if ($Age == "20-30")    echo selected ?>>20-30 </option>
                <option value="31-40" <?php if ($Age == "31-40")    echo selected ?>>31-40 </option>
                <option value="41-50" <?php if ($Age == "41-50")    echo selected ?>>41-50 </option>
                <option value="51-60" <?php if ($Age == "51-60")    echo selected ?>>51-60 </option>
                <option value="Above_60" <?php if ($Age == "Above_60") echo selected ?>>Above 60 </option>
              </select>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td> <!--Empty Row-->
          </tr>
          <!--Radio Buttons-->
          <tr>
            <td style="width: 7%; text-align: right;">Game Genre</td>
            <td style="width: 20%; text-align: left;">
              <table style="width: 100%;">
                <tr>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "FPS")   echo "checked"; ?> name="Genre" value="FPS" checked> FPS&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Adventure") echo "checked"; ?> name="Genre" value="Adventure"> Adventure&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Mystery")   echo "checked"; ?> name="Genre" value="Mystery" checked> Mystery&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Horror") echo "checked"; ?> name="Genre" value="Horror"> Horror&nbsp;</td>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <!--Checkboxes-->
          <tr>
            <td style="width: 7%; text-align: right">Game Type &nbsp;</td>
            <td style="width: 20%; ">
              <table style="width: 100%;">
                <tr>
                  <td style="width: 20%;">
                    <input type="checkbox" name="Singleplayer" 
                    <?php if ($Singleplayer == "Singleplayer") echo checked;?> value="Singleplayer"> Singleplayer&nbsp;&nbsp;
                  </td>
                  <td style="width: 20%;">
                    <input type="checkbox" name="MMO" 
                    <?php if ($MMO == "MMO") echo checked;?> value="MMO"> MMO&nbsp;&nbsp;
                  </td>
                  <td style="width: 20%;">
                    <input type="checkbox" name="SplitScreen" 
                    <?php if ($SplitScreen == "SplitScreen") echo checked;?> value="SplitScreen"> Split Screen&nbsp;&nbsp;
                  </td>
                  <td style="width: 20%;">
                    <input type="checkbox" name="CoOp" 
                    <?php if ($CoOp == "CoOp") echo checked;?> value="CoOp"> Co-Op
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
          <td>&nbsp;</td> <!--Empty Row-->
          </tr>
          <table style="width:100%;">
            <tr>
              <td style="text-align:center;"><?php echo $message ?></td>
            </tr>
          </table>
          <td>&nbsp;</td> <!--Empty Row-->
          <table style="width:100%;">
            <tr>
              <td style="text-align:center;">
                <input type="submit" name="Save" value="Save">&nbsp; 
                <input type="submit" name="Find" value="Find">&nbsp; 
                <input type="submit" name="Modify" value="Modify">&nbsp; 
                <input type="submit" name="Delete" value="Delete">&nbsp; 
                <input type="submit" name="Clear" value="Clear Screen">&nbsp; 
                <input type="submit" name="submit" value="Contact_Me">
                <input type="hidden" name="found" value="<?php echo $found ?>">
              </td>
            </tr>
          </table>
          <td>&nbsp;</td> <!--Empty Row-->
          <?php include ( 'mainMenu.php' ); ?>
          <td>&nbsp;</td> <!--Empty Row-->
          <center>Hytham Jurdi</center>
      </form>
    </header> 
    
  </body>
</html>