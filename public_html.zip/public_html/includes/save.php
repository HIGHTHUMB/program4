<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->
<!-- ***********************************************************************************
  Page Name  : Save Button
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Saves data from front end to SQL

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<html>
    
  <body>
     
    <!--br><h3>this is save.php</h3><br-->
       
     
    <?php
 /* 
          echo "This is controller3.php. <br>";
          echo "I was called from program 3. <br><br>";
          echo "You pressed the Save button.<br><br>";
          echo $Telephone."<br>"; 
          echo $Email."<br>";  
          echo $LastName."<br>";  
          echo $FirstName."<br>";  
          echo $Address."<br>";
          echo $City."<br>";
          echo $State."<br>";
          echo $Country."<br>";
          echo $Zip."<br>";
          echo $Age."<br>";
          echo $Genre."<br>";
          echo $Type."<br>";
          echo $Comments."<br>";
*/          
          
        
       //echo "Inserting record into table ".$tableName."<br>";
      
                  
                
       $Telephone=trim($Telephone);
       if(strlen($Telephone)>0)           
       {   
          $sql="INSERT INTO customers (
                  Telephone,
                  Email,
                  LastName,
                  FirstName,
                  Address,
                  City,
                  State,
                  Country,
                  Zip,
                  Age,
                  Genre,
                  Singleplayer,
                  MMO,
                  SplitScreen,
                  CoOp,
                  Comments
               )
               VALUES
               (            
                  '$Telephone',
                  '$Email',
                  '$LastName',
                  '$FirstName',
                  '$Address',
                  '$City',
                  '$State',
                  '$Country',
                  '$Zip',
                  '$Age',
                  '$Genre',
                  '$Singleplayer',
                  '$MMO',
                  '$SplitScreen',
                  '$CoOp',
                  '$Comments'                     
               )";
                
                  
          if (mysqli_query($connection, $sql)) 
          {
             //echo "<br>New record created successfully!";
             $message ="<span style=\"color: blue;\">RECORD $Telephone ADDED</span><br\>";
          } 
          else
          {
             //echo "<br>Error: " . $sql . "<br>" . mysqli_error($connection);
             $message ="<span style=\"color: red;\">RECORD $Telephone ALREADY EXISTS</span><br\>";
          }
           
       }//end if(strlen($Telephone)>0)                      
       else
       {
          //echo "<br>Record could not be added.<br>";
          //echo "<br>Telephone CAN NOT BE EMPTY!";
          $message ="<span style=\"color: red;\">RECORD NOT ADDED<BR>Telephone CAN NOT BE EMPTY</span><br\>";
       } 
             
    ?>
       
  </body>

</html>
