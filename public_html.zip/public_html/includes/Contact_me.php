<!-- ***********************************************************************************
  Page Name  : Contact Me Page
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : A page to contact me via email

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->

<title>Contact Me</title>

    <?php include ( 'Jurdi_header.php' ); ?>
    <tr><td>&nbsp;</td> <!--Empty Row--></tr>
    <p align="center"><b><font size="3" color="red">CONTACT ME</font></b></p>
    <tr><td>&nbsp;</td> <!--Empty Row--></tr>
    <?php include ( 'mainMenu.php' ); ?>
    <tr><td>&nbsp;</td> <!--Empty Row--></tr>

 <center>
        <form method="post" action="Contact_me_Controller.php">
        <table style="width: 50%; margin: 0px auto; padding-right: 10%;">
          <!--  text type input  -->
          <tr>
            <td style="width: 5%; text-align: left;">Your Email&nbsp;</td>
            <td style="width: 20%;">
              <input id="birth" type="text" name="Email" value="<?php echo $Email ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: left;">Last Name&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="LastName" value="<?php echo $LastName ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: left;">First Name&nbsp;</td>
            <td style="width: 20%;">
              <input type="text" name="FirstName" value="<?php echo $FirstName ?>" style="width: 100%;">
            </td>
          </tr>
          
          <tr><td>&nbsp;</td></tr> <!--Empty Row-->
          
          <!--Radio Buttons-->
          <tr>
            <td style="width: 7%; text-align: left;">Game Genre</td>
            <td style="width: 20%; text-align: left;">
              <table style="width: 100%;">
                <tr>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "FPS")   echo "checked"; ?> name="Genre" value="FPS" checked> FPS&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Adventure") echo "checked"; ?> name="Genre" value="Adventure"> Adventure&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Mystery")   echo "checked"; ?> name="Genre" value="Mystery" checked> Mystery&nbsp;</td>
                  </td>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <!--Checkboxes-->
          <tr>
             <td style="width: 7%; text-align: left">Game Type &nbsp;</td>
             <td style="width: 20%; ">
             <table style="width: 100%;">
             <tr>
               <td style="width: 20%;">
               <input type="checkbox" name="Type[]" value="Singleplayer" <?php if (in_array("Singleplayer", $Type)) echo "checked"; ?>>Singleplayer </td>
               <td style="width: 20%;">
               <input type="checkbox" name="Type[]" value="MMO" <?php if (in_array("MMO", $Type)) echo "checked"; ?>>MMO</td>
               <td style="width: 20%;">
               <input type="checkbox" name="Type[]" value="SplitScreen" <?php if (in_array("SplitScreen", $Type)) echo "checked"; ?>>SplitScreen</td>
             </tr>
             </table>
             </td>
          </tr>

        
          <tr><td>&nbsp;</td></tr> <!--Empty Row-->
          
          <!--  dropdown boxes -->
          <tr>
            <td style="width: 5%; text-align: left;">Age&nbsp;</td>
            <td style="width: 20%; text-align: left;">
              <select name="Age" style="width: 100%" size="1" ;>
                <option value="Under_20" <?php if ($Age == "Under_20") echo selected ?>>Under 20 </option>
                <option value="20-30" <?php if ($Age == "20-30")    echo selected ?>>20-30 </option>
                <option value="31-40" <?php if ($Age == "31-40")    echo selected ?>>31-40 </option>
                <option value="41-50" <?php if ($Age == "41-50")    echo selected ?>>41-50 </option>
                <option value="51-60" <?php if ($Age == "51-60")    echo selected ?>>51-60 </option>
                <option value="Above_60" <?php if ($Age == "Above_60") echo selected ?>>Above 60 </option>
              </select>
            </td>
          </tr>
          
          <tr><td>&nbsp;</td></tr> <!--Empty Row-->
          
          <!--  textarea box  -->
          <tr>
            <td style="width: 7%; text-align:left;">Comments &nbsp;</td>
            <td style="width: 20%;">
              <textarea name="Comments" style="width: 99%;" rows="5" cols="50"><?php echo $Comments;?></textarea>
            </td>
          </tr>

          <tr><td>&nbsp;</td></tr> <!--Empty Row-->

          <table style="width:100%;">
            <tr>
              <td style="text-align:center;">
                <input type="submit" value="Submit" name="submit">&nbsp; 
                <input type="submit" name="Clear" value="Clear">
                <input type="hidden" name="found" value="<?php echo $found ?>">
              </td>
            </tr>
          </table>
          <td>&nbsp;</td> <!--Empty Row-->

      </form>
    </header> 
    
  </body>

   <?php include ( 'mainMenu.php' ); ?>

