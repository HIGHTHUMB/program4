  <!-- ***********************************************************************************
  Page Name  : About Page
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #4
  Purpose    : About page that explains the purpose of the website, the usage, what I have learned, and my reason for choosing gaming as a topic.

  Due Date   : 04/13/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<html>
  <title>About</title>
  <head>
  <?php include ( 'Jurdi_header.php' ); ?>
  <?php include ( 'mainMenu.php' ); ?>
  
  <style type="text/css">
        
       .helpHeadings1
       { 
         font-family:Helvetica; 
         font-size:11pt;
         style="height:5px";
         color: white;
         background-color:green;
         border-radius: 12px;
       }
       
       .helpHeadings2
       { 
         font-family:Helvetica; 
         font-size:11pt;
         style="height:5px";
         color: blue;
       }
         
       .helpHeadings3
       { 
         font-family:Helvetica; 
         font-size:11pt;
         style="height:5px";
         color: black;
         a:visited color: blue;
       }
        
        
       .MainHeadings20
       { 
         font-family:Helvetica; 
         font-size:15pt;
         style="height:5px";
         color: red;
       }
        
     </style> 
  </head>
  <body link="blue" vlink="blue" alink="red">
     <div align="center">
       <h2 class="MainHeadings20">ABOUT</h2>
         
       <table width="100%" border="0"  BORDERCOLOR=red  border-spacing: 15px; >
         <tr> 
           <td> 
             <b><center><p style="font-size:25px">
             About My Website & Myself</p></center><br>
                 
               <table width="100%" border="0"  BORDERCOLOR=RED  border-spacing: 15px; >
                 <td width="50%" style="border:solid 2px #ff0000">
                   <br>
                   &nbsp; &nbsp; &nbsp; <a class="helpHeadings1"><b>&nbsp; Website &nbsp;</a><br>
                                          
                   <ul style="list-style-type:square"> 
                     <li> <a class="helpHeadings2">Purpose<br></a>
                       <a class="helpHeadings3">The purpose of this website changes throughout the course.<br>
                       In the end, the website contains input fields that can be uploaded to an SQL server. <br>This data can be found, modified, or deleted using the <span style="color: red;">primary key</span>.</a>
                          
                     <li> <a class="helpHeadings2">Languages<br></a>
                     <a class="helpHeadings3">This website contains the following languages: <u><span style="color: green;">HTML, PHP, CSS, SQL, and JavaScript.</span></u></a>
                          
                     <li> <a class="helpHeadings2">Pages<br></a>
                     <a class="helpHeadings3">Below is a list of the main the pages on the website<br>
                     <ul style="list-style-type:disc">
                     <li><a href="../index.html">Home</a>
                     <li><a href="pgm1.html">Program 1</a>
                     <li><a href="program2.php">Program 2</a>
                     <li><a href="program3.php">Program 3</a>
                     <li><a href="program4.php">Program 4</a>
                     <li><a href="Contact_me.php">Contact Me</a>
                     </a>
                     </ul>
                     <li> <a class="helpHeadings2">Contact Me<br>
                     <a class="helpHeadings3">If you would like to contact me, my email is <a href="mailto:hjurdi001@fiu.edu">hjurdi001@fiu.edu</a></a>
                     </a>
                     <li> <a class="helpHeadings2">What I've Learned<br></a>
                     <a class="helpHeadings3">I have learned many things in this class. I have learned how to build my own website from the ground up.<br>
                     I have learned how to write in the extremely versatile language HTML and how to incorporate other languages inside of it.
                     I have learned how to input data, pass it to a controller page, and even upload it to an SQL server where the data can be found, modified, saved, deleted etc.</a>
                   </ul>
                 </td>
                    
                    
                 <td width="50%" style="border:solid 2px #ff0000">
                   
                   &nbsp; &nbsp; &nbsp; <a class="helpHeadings1"><b>&nbsp; Myself &nbsp;</a><br>
                               
               <ul style="list-style-type:square" color="red"> 
                 <li> <a class="helpHeadings2" align="left">Reason for choosing Gaming<br></a>
                   <a class="helpHeadings3"> Personally, I love gaming because it allows me to immerse myself in different worlds and take on new identities, which helps me escape from reality and forget about my problems for a while. 
                   Gaming is a great way to connect with friends and meet new people who share my interests, as well as a way to challenge myself mentally and improve my problem-solving skills. 
                   Gaming offers a form of entertainment that is constantly evolving and pushing the boundaries of what is possible, making it an exciting and rewarding hobby.</a><br>    

                 <li> <a class="helpHeadings2">Recent Gaming<br></a>
                 <a class="helpHeadings3">Lately my obsession has been with Sim Racing/Drifting. It is something I have fallen in love with and have invested time and money into mastering.</a><br>
                 
                 <li> <a class="helpHeadings2">Favorite Games<br></a>
                 <a class="helpHeadings3">My favorite games of all time are 
                 <a href="https://elderscrolls.bethesda.net/en/skyrim"> Elder Scrolls V: Skyrim</a>, 
                 <a href="https://www.zelda.com/breath-of-the-wild/">Zelda: Breath of the Wild</a>, 
                 and <a href="https://zelda.fandom.com/wiki/The_Legend_of_Zelda:_Twilight_Princess">Zelda: Twilight Princess</a>. 
                 <a class="helpHeadings3"> These are games that I have played multiple times and put many hours into.
                 They all have encapsulating stories that make you forget about reality while playing.</a></a>
                 <li> <a class="helpHeadings2">Last Words<br></a>
                   <a class="helpHeadings3">Gaming is more than just a hobby. It is a way of life. It is a way of escaping every day stress and finding yourself immersed in a new world.
                   I recommend everyone finds a game that can bring them as much joy as it has to me.</a>
               </ul>
             </td>
                   
           </table>  
         </td>
       </tr>
     </table> 
    
   </div>
   <center>
      <a href="https://en.wikipedia.org/wiki/History_of_video_games">
          <img src="../images/botw.jpg" alt="Zelda Breath of the Wild"
          width="600" height="300" border=3 />
      </a>
      <a href="https://en.wikipedia.org/wiki/Sim_racing">
           <img src="../images/simrig.jpg" alt="Sim Rig"
           width="600" height="300" border=3 />
      </a> 
      <a href="https://console.assettocorsa.net/">
           <img src="../images/assetto.jpg" alt="Assetto Corsa"
           width="600" height="300" border=3 />
      </a> 
   </center>   
      <td width="60%" bgcolor=white >
        <table width="100%">
          <tr width="75%" bgcolor=red >
            <HR>
            <p align="center"><b><font face="Helvetica" size="2" color="#FFFFFF">
              <marquee bgcolor="#0348E6" halign="center" scrollamount="3" behavior="scroll" direction="left">
         Hytham Jurdi's Gaming Website | Information Technology | CGS4854 Online Class - Professor Robinson | Florida International University, Miami FL
              </marquee></font></b>
            </p>
            <HR>
          </tr>
  </body>
</html>
