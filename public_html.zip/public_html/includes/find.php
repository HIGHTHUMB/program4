<!-- ***********************************************************************************
  Page Name  : Find Button
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Finds data using primary key

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>
                     
  <body>
                       
    <!--h3>this is find.phd</h3-->
                        
    <?php
         
 /*           
       echo  "find.php Telephone = [".$Telephone."]<br>";
       echo "LastName      = " . $_POST['LastName'] . "<br>";
       echo "FirstName     = " . $_POST['FirstName'] . "<br>";
       echo "Email         = " . $_POST['Email'] . "<br>";
       echo "Address       = " . $_POST['Address'] . "<br>";
       echo "City          = " . $_POST['City'] . "<br>";
       echo "State         = " . $_POST['State'] . "<br>";
       echo "Country       = " . $_POST['Country'] . "<br>";
       echo "Zip           = " . $_POST['Zip'] . "<br>";
       echo "Comments      = " . $_POST['Comments'] . "<br>";
       echo "Age           = " . $_POST['Age'] . "<br>";
       echo "Genre         = " . $_POST['Genre'] . "<br>";
       echo "Singleplayer  = " . $_POST['Singleplayer'] . "<br>";    
       echo "MMO           = " . $_POST['MMO'] . "<br>";  
       echo "SplitScreen   = " . $_POST['SplitScreen'] . "<br>";
       echo "OnlineCoOp    = " . $_POST['OnlineCoOp'] . "<br>";

       //echo "find.php table : ".$tableName."<br>";

       //echo "<br>find.php  found = [" . $found . "]";
       $found = $Telephone;
        
       //echo "<br>find.php Found = Telephone = [" . $found . "]";
 */               
           
                  
       //$sql="SELECT * FROM customers ORDER BY Telephone";
           
       $sql="SELECT * FROM customers where Telephone = '$Telephone'";
             
       if ($result=mysqli_query($connection,$sql))
       {
          //printf("Result of mysqli_query(connection,sql) = %d<br>", $result);
          
          // Return the number of rows in result set
          $rowcount=mysqli_num_rows($result);
                   
          //printf("Result set has %d rows.\n",$rowcount);
             
                        
          while( $row = mysqli_fetch_array( $result ) )
          {
             $Telephone    = $row['Telephone'];     //primary key
             $Email        = $row['Email'];         //type="text"
             $LastName     = $row['LastName'];      //type="text"
             $FirstName    = $row['FirstName'];     //type="text"
             $Address      = $row['Address'];       //type="text"
             $City         = $row['City'];          //type="text"
             $State        = $row['State'];         //type="text"
             $Country      = $row['Country'];       //type="text"
             $Zip          = $row['Zip'];           //type="text"
             $Comments     = $row['Comments'];      //type="textarea"  
             $Age          = $row['Age'];           //type="dropdown" 
             $Genre        = $row['Genre'];         //type="radio"
             $Singleplayer = $row['Singleplayer'];  //type="checkbox"
             $MMO          = $row['MMO'];           //type="checkbox"
             $SplitScreen  = $row['SplitScreen'];   //type="checkbox"
             $CoOp         = $row['CoOp'];          //type="checkbox"
       
          }


/*
          echo $Telephone."<br>"; 
          echo $Email."<br>";  
          echo $LastName."<br>"; 
          echo $FirstName."<br>";  
          echo $Address."<br>";  
          echo $City."<br>";  
          echo $State."<br>";  
          echo $Country."<br>";
          echo $Zip."<br>";
          echo $Comments."<br>";
          echo $Age."<br>";  
          echo $Genre."<br>";  
          echo $Type."<br>"; 
*/



          //printf("\ni am here in find.php\n [%s] [%s]", $Telephone, $FirstName );
          //echo "(".$Telephone." ".$FirstName.")";


          $Telephone=trim($Telephone); //take all front and back spaces out

                
          //if (mysqli_query($connection, $sql)) 
          if ( $rowcount )
          {
             $found = $Telephone;
             $message ="<span style=\"color: blue;\">RECORD $found FOUND</span><br\>";
             //echo "found";
          } 
          else if( strlen($Telephone) ==0 )           
          {
             $message ="<span style=\"color: red;\">Telephone CAN NOT BE EMPTY</span><br>";
             //echo "<br>Error: " . $sql . " " . mysqli_error($connection);
                  
             //clear data in variables       
             //$Telephone    = "";
             $Email        = "";
             $LastName     = "";
             $FirstName    = "";
             $Address      = "";
             $City         = "";
             $State        = "";
             $Country      = "";
             $Zip          = "";
             $Comments     = "";
             $Age          = "";
             $Genre        = "";
             $Age          = "";
             $Singleplayer = "";
             $MMO          = "";
             $SplitScreen  = "";
             $CoOp         = "";
             
             $found        = "";  
          }
          else 
          {
             $message ="<span style=\"color: red;\">RECORD $Telephone NOT FOUND</span><br>";
             //echo "<br>Error: " . $sql . " " . mysqli_error($connection);
                  
             //clear data in variables       
             //$Telephone    = "";
             $Email        = "";
             $LastName     = "";
             $FirstName    = "";
             $Address      = "";
             $City         = "";
             $State        = "";
             $Country      = "";
             $Zip          = "";
             $Comments     = "";
             $Age          = "";
             $Genre        = "";
             $Age          = "";
             $Singleplayer = "";
             $MMO          = "";
             $SplitScreen  = "";
             $CoOp         = "";           
                      
             $found        = "";  
          }
             
      }
                 
   ?>

  </body>

</html>