<!-- ***********************************************************************************
  Page Name  : Controller
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #2
  Purpose    : Controller that handles my inputs on program2.php

  Due Date   : 02/19/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->

<!DOCTYPE html>

<html>
  <head>
  <?php       
       //extract the data inputed by the user creating global php fields 
       $Telephone     = $_POST['Telephone'];
       $FirstName     = $_POST['FirstName'];
       $LastName      = $_POST['LastName'];
       $Email         = $_POST['Email'];
       $Address       = $_POST['Address'];
       $City          = $_POST['City'];
       $State         = $_POST['State'];
       $Country       = $_POST['Country'];
       $Zip           = $_POST['Zip'];
       $Age           = $_POST['Age'];
       $Genre         = $_POST['Genre'];
       $Type         = $_POST['Type'];
       $Comments      = $_POST['Comments'];            
       $Save          = $_POST['Save'];
       $Find          = $_POST['Find'];
       $Modify        = $_POST['Modify'];
       $Delete        = $_POST['Delete'];
       
       $found = $_POST['found']; 
       
       //verify that the data entered by the user is being received
       if ( $_POST['Find'] )
       { 
          include('find.php');
          echo "This is controller2.php. <br>";
          echo "I was called from program 2. <br><br>";
          echo "You pressed the Find button.<br><br>";
          echo "Telephone     = " . $_POST['Telephone'] . "<br>";
          echo "FirstName     = " . $_POST['FirstName'] . "<br>";
          echo "LastName      = " . $_POST['LastName'] . "<br>";
          echo "Email         = " . $_POST['Email'] . "<br>";
          echo "Address       = " . $_POST['Address'] . "<br>";
          echo "City          = " . $_POST['City'] . "<br>";
          echo "State         = " . $_POST['State'] . "<br>";
          echo "Country       = " . $_POST['Country'] . "<br>";
          echo "Zip           = " . $_POST['Zip'] . "<br>";
          echo "Comments      = " . $_POST['Comments'] . "<br>";
          echo "Age           = " . $_POST['Age'] . "<br>";
          echo "Genre         = " . $_POST['Genre'] . "<br>";
          echo "Game Type     = " . $_POST['Type'] . "<br>";
       }
       else if ( $_POST['Save'] )
       { 
          include('save.php');
          echo "This is controller2.php. <br>";
          echo "I was called from program 2. <br><br>";
          echo "You pressed the Save button.<br><br>";
          echo "Telephone     = " . $_POST['Telephone'] . "<br>";
          echo "FirstName     = " . $_POST['FirstName'] . "<br>";
          echo "LastName      = " . $_POST['LastName'] . "<br>";
          echo "Email         = " . $_POST['Email'] . "<br>";
          echo "Address       = " . $_POST['Address'] . "<br>";
          echo "City          = " . $_POST['City'] . "<br>";
          echo "State         = " . $_POST['State'] . "<br>";
          echo "Country       = " . $_POST['Country'] . "<br>";
          echo "Zip           = " . $_POST['Zip'] . "<br>";
          echo "Comments      = " . $_POST['Comments'] . "<br>";
          echo "Age           = " . $_POST['Age'] . "<br>";
          echo "Genre         = " . $_POST['Genre'] . "<br>";
          echo "Game Type     = " . $_POST['Type'] . "<br>";
       }
       else if ( $_POST['Modify'] )
       {  
          include('modify.php');
          echo "This is controller2.php. <br>";
          echo "I was called from program 2. <br><br>";
          echo "You pressed the Modify button.<br><br>";
          echo "Telephone     = " . $_POST['Telephone'] . "<br>";
          echo "FirstName     = " . $_POST['FirstName'] . "<br>";
          echo "LastName      = " . $_POST['LastName'] . "<br>";
          echo "Email         = " . $_POST['Email'] . "<br>";
          echo "Address       = " . $_POST['Address'] . "<br>";
          echo "City          = " . $_POST['City'] . "<br>";
          echo "State         = " . $_POST['State'] . "<br>";
          echo "Country       = " . $_POST['Country'] . "<br>";
          echo "Zip           = " . $_POST['Zip'] . "<br>";
          echo "Comments      = " . $_POST['Comments'] . "<br>";  
          echo "Age           = " . $_POST['Age'] . "<br>";
          echo "Genre         = " . $_POST['Genre'] . "<br>";
          echo "Game Type     = " . $_POST['Type'] . "<br>";        
       }
       else if ( $_POST['Delete'] )
       { 
          include('delete.php');
          echo "This is controller2.php. <br>";
          echo "I was called from program 2. <br><br>";
          echo "You pressed the Delete button.<br><br>"; 
          echo "Telephone     = " . $_POST['Telephone'] . "<br>";
          echo "FirstName     = " . $_POST['FirstName'] . "<br>";
          echo "LastName      = " . $_POST['LastName'] . "<br>";
          echo "Email         = " . $_POST['Email'] . "<br>";
          echo "Address       = " . $_POST['Address'] . "<br>";
          echo "City          = " . $_POST['City'] . "<br>";
          echo "State         = " . $_POST['State'] . "<br>";
          echo "Country       = " . $_POST['Country'] . "<br>";
          echo "Zip           = " . $_POST['Zip'] . "<br>";
          echo "Comments      = " . $_POST['Comments'] . "<br>";
          echo "Age           = " . $_POST['Age'] . "<br>";
          echo "Genre         = " . $_POST['Genre'] . "<br>";
          echo "Game Type     = " . $_POST['Type'] . "<br>";
       }
       else if ( $_POST['Clear'] )
       {
          include('clear.php');
       }
       else
       { 
          echo "";   
       }
    ?>
    <title>ControllerPgm2</title>
  </head>   
    <body>
    </body>

</html>