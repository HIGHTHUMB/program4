<!-- ***********************************************************************************
  Page Name  : Clear Button
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Clears the data from frontend.

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>
       
  <body>
                      
    <!--br><h3>this is clear.phd</h3><br-->
                        
                
    <?php
         
       
  $Telephone     = '';  
  $Email         = '';
  $LastName      = ''; 
  $FirstName     = '';
  $Address       = '';
  $City          = '';
  $State         = '';
  $Country       = '';
  $Zip           = '';
  $Comments      = ''; 
  $Age           = '';
  $Genre         = '';
  $Singleplayer  = '';  
  $MMO           = '';      
  $SplitScreen   = ''; 
  $CoOp          = ''; 
  

                  
       $found        = "";  
    
    ?>
              
  </body>
            
</html>