<!-- ***********************************************************************************
  Page Name  : Program 2 Page 
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #2
  Purpose    : Program 2 Page that includes 3 php files, contains a table with text inputs, radio buttons, submit buttons, and passes data to controller.

  Due Date   : 02/19/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<!doctype html>

<html>

<head>
<title>JurdiHProgram2</title>
</head>

<body>
<header>
    <?php include ( 'Jurdi_header.php' ); ?>
    <?php include ( 'mainMenu.php' ); ?>
   
<form method="post" action="Controller2.php">
         <table style="width: 50%; margin: 0px auto; padding-right: 10%;">
                   
            <!--  text type input  -->
            <tr>
               <td style="width: 5%; text-align: right;">Telephone&nbsp;</td> 
               <td style="width: 20%;">
                  <input type="text" name="Telephone" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">Email&nbsp;</td>
               <td style="width: 20%;">
                  <input id="birth" type="text" name="Email" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">Last Name&nbsp;</td>
               <td style="width: 20%;">
                  <input type="text" name="LastName" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">First Name&nbsp;</td>
               <td style="width: 20%;">
                  <input type="text" name="FirstName" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">Address&nbsp;</td>
               <td style="width: 20%;">
                  <input type="text" name="Address" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">City&nbsp;</td>
               <td style="width: 20%;">
                  <input type="text" name="City" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">State&nbsp;</td>
               <td style="width: 20%;">
                  <input type="text" name="State" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">Country&nbsp;</td>
               <td style="width: 20%;">
                  <input type="text" name="Country" value="" style="width: 100%;">
               </td>
            </tr>
            <tr>
               <td style="width: 5%; text-align: right;">Zip&nbsp;</td>
               <td style="width: 20%;">
                  <input type="text" name="Zip" value="" style="width: 100%;">
               </td>
            </tr>

            <tr><td>&nbsp;</td> </tr>
                       <!--  textarea box  -->
            <tr>
                <td style="width: 7%; text-align:right;">Comments &nbsp;</td>
                <td style="width: 20%;">
                <textarea name="Comments" rows="5" cols="35"></textarea>
               </td>
           </tr>
            <!--  dropdown boxes -->
            <tr>
               <td style="width: 5%; text-align: right;">Age&nbsp;</td>
               <td style="width: 20%; text-align: left;">
                   <select name="Age" style="width: 100%"size="1";>
                      <option value="Under_20" <?php if ($Age == "Under_20") echo selected ?> >Under 20   </option>
                      <option value="20-30"    <?php if ($Age == "20-30")    echo selected ?> >20-30      </option>
                      <option value="31-40"    <?php if ($Age == "31-40")    echo selected ?> >31-40      </option>
                      <option value="41-50"    <?php if ($Age == "41-50")    echo selected ?> >41-50      </option>
                      <option value="51-60"    <?php if ($Age == "51-60")    echo selected ?> >51-60      </option>
                      <option value="Above_60" <?php if ($Age == "Above_60") echo selected ?> >Above 60   </option>
                   </select>
               </td>
            </tr>
            
            <tr><td>&nbsp;</td> </tr>            
            
            <!--  radio buttons  -->
            <tr>
               <td style="width: 5%; text-align: right;">Game Genre&nbsp;</td>
               <td style="width: 20%; text-align: left;">
                  <table>
                     <tr>
                       <td text-align: left> 
                         <input type="radio" <?php if ($Genre == "FPS")   echo "checked"; ?> 
                                name="Genre" value="FPS" checked> FPS&nbsp;
                         <input type="radio" <?php if ($Genre == "Adventure") echo "checked"; ?> 
                                name="Genre" value="Adventure"> Adventure&nbsp;
                         <input type="radio" <?php if ($Genre == "Mystery")   echo "checked"; ?> 
                                name="Genre" value="Mystery" checked> Mystery&nbsp;
                         <input type="radio" <?php if ($Genre == "Horror") echo "checked"; ?> 
                                name="Genre" value="Horror"> Horror&nbsp;
                        </td>
                     </tr>
                  </table>
               </td>
            </tr>
                             
            <tr><td>&nbsp;</td> </tr>                                         
                    
            <!-- CheckBoxes -->
            <tr>
              <td style="width: 5%; text-align: right">Game Type&nbsp;</td>
              <td style="width: 20%;">
                <table>
                  <tr>                                    
                    <td><input type="checkbox" name="Type" 
                      <?php if ($Type == "Singeplayer") echo checked;?>  value="Singeplayer" > Singeplayer&nbsp;&nbsp; </td>
                        
                    <td><input type="checkbox" name="Type" 
                      <?php if ($Type == "MMO") echo checked;?>  value="MMO" > MMO&nbsp;&nbsp; </td>
                      
                    <td><input type="checkbox" name="Type" 
                      <?php if ($Type == "Split Screen") echo checked;?>   value="Split Screen" > Split Screen&nbsp;&nbsp; </td>

                    <td><input type="checkbox" name="Type" 
                      <?php if ($Type == "Online Co-Op") echo checked;?>  value="Online Co-Op" > Online Co-Op  </td>
                  </tr>      
                </table>
              </td>
            </tr>   
            
            <tr><td>&nbsp;</td> </tr>                          
              

               
               
            <tr><td>&nbsp;</td> </tr>  
           <tr>
           <td style="width: 7%;"></td>
               <td style="width: 20%;"align=center>$message
           </tr> 

            <tr><td> &nbsp; </td> </tr>                                         

            <tr>
               <td style="width: 15%;"> </td>            
               <td style="text-align: center;" colspan="2">
                  <input type="submit" name="Save"   value="Save">&nbsp;
                  <input type="submit" name="Find"   value="Find">&nbsp;
                  <input type="submit" name="Modify" value="Modify">&nbsp;
                  <input type="submit" name="Delete" value="Delete">&nbsp;
                  <input type="reset" name="Clear Screen"  value="Clear Screen">
                  <input type="hidden" name="found"  value="<?php echo $found ?>" > 
               </td>
            </tr>
            
         </table>
      </form>
   </div>			
</header>
 <?php include ( 'Controller2.php' ); ?>
 <?php include ( 'mainMenu.php' ); ?>
</body>
</html>