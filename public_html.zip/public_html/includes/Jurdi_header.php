<!-- ***********************************************************************************
  Page Name  : Header Page 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #2
  Purpose    : Describe what this page does 

  Due Date   : 02/19/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->

<html>

<head>

<title>Jurdi_header.php</title>

</head>

<body>
<header>
<center><H1><font face="Arial" color="red"><?php echo "====This is a Teaching Website====";?></font></H1></center>
<center><font face="Times New Roman" color="red" size="6"><?php echo "Hytham Jurdi";?></font></center>
<hr color="green">


</header>

</body>

</html>