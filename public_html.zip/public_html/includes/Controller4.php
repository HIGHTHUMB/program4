<!-- ***********************************************************************************
  Page Name  : Controller for program 4
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #4
  Purpose    : Controller that handles my inputs on program4.php

  Due Date   : 04/13/2023

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->

<!DOCTYPE html>

<html>
  <head>
  <?php       
  
       //connecting to mysql 
       //echo "<h3>I am going to connect to mySql";

       //                                server               user        password   database     
       $connection = mysqli_connect("                 ","              ","         ","        ");
       if (mysqli_connect_errno())
       {
          echo "Failed to connect to MySQL: " . mysqli_connect_error();
       }
       else
       {  
          //echo "<br>I have connected to mySql<br>";            
             
          // Change database to another name if needed
             
          $dbName="name"; 
          $db_selected = mysqli_select_db( $connection, $dbName );
                      
          if (!$db_selected)
          {
             die( $dbName . ' does not exist, can\'t use it ' . mysqli_error());
          }
          else
          {
             //echo "I selected database : " . $db_selected . " " . $dbName . "<br></h3>" ;
                   
             //access to a table                    
             $tableName = "customers";
                      
             $query = mysqli_query( $connection, "SELECT * FROM $tableName" );
                     
             //if table does not exist, create it 
             if(!$query)
             {
                //echo "The ".$tableName." does not exists<br>";
                        
                //echo "<br>Creating table : ".$tableName."<br>";
                       
                $sql = "CREATE TABLE ".$tableName."(
                        Telephone VARCHAR(20) NOT NULL,
                        PRIMARY KEY(Telephone),
                        Email VARCHAR(30),
                        LastName VARCHAR(30),
                        FirstName VARCHAR(30),
                        Address VARCHAR(30),
                        City VARCHAR(30),
                        State VARCHAR(30),
                        Country VARCHAR(30),
                        Zip VARCHAR(30),
                        Comments VARCHAR(200),
                        Age VARCHAR(8),
                        Genre VARCHAR(10),
                        Singleplayer VARCHAR(12),
                        MMO VARCHAR(12),
                        SplitScreen VARCHAR(12),
                        CoOp VARCHAR(12)
                        )";
                                
                $result = mysqli_query( $connection, $sql );
                         
                //confirm table creation
                if ($result)
                {
                   //echo "table ". $tableName." created<br>";
                }
                else
                {
                   die ("Can\'t create ". $tableName." ". mysqli_error() );
                }
                     
             }//if(!$query) if table does not exist, create it 
                        
          }//end if (!$db_selected) connecting to db
                
       }//end if (mysqli_connect_errno()) connecting to mysql
  
  
  
       //extract the data inputed by the user creating global php fields 
       $Telephone     = $_POST['Telephone'];
       $FirstName     = $_POST['FirstName'];
       $LastName      = $_POST['LastName'];
       $Email         = $_POST['Email'];
       $Address       = $_POST['Address'];
       $City          = $_POST['City'];
       $State         = $_POST['State'];
       $Country       = $_POST['Country'];
       $Zip           = $_POST['Zip'];
       $Age           = $_POST['Age'];
       $Genre         = $_POST['Genre'];
       $Singleplayer  = $_POST['Singleplayer'];  
       $MMO           = $_POST['MMO'];      
       $SplitScreen   = $_POST['SplitScreen']; 
       $CoOp          = $_POST['CoOp']; 
       $Comments      = $_POST['Comments'];  
       
       $found = $_POST['found']; 
       
       //verify that the data entered by the user is being received   
       if ( $_POST['Find'] )
       { 
          include('find.php');
          include('program4.php');

       }
       else if ( $_POST['Save'] )
       { 
          include('save.php');
          include('program4.php');

       }
       else if ( $_POST['Modify'] )
       {  
          include('modify.php');  
          include('program4.php');

        
       }
       else if ( $_POST['Delete'] )
       { 
          include('delete.php');
          include('program4.php');

       }
       else if ( $_POST['Clear'] )
       {
          include('clear.php');
          include('program4.php');

       }
       else if ( $_POST['submit'] )
       {
          include('Contact_me.php');
       }
       else if ( $_POST['help'] )
       {
          include('help.php');
          include('program4.php');
       }
       else if ( $_POST['about'] )
       {
          include('about.php');
       }
       else
       { 
          echo "";   
          
       }

       mysqli_close($connection);
       
    ?>
    <title>ControllerPgm4</title>
  </head>   
    <body>
    </body>

</html>