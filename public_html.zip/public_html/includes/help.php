<html>
<!-- ***********************************************************************************
  Page Name  : Help button for program 4
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #4
  Purpose    : Pop up page that describes what each button does.

  Due Date   : 04/13/2023

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<head>
<body>

<script>

help();

function help()
{
   // Open a new window at a specific location
        var myWindow = window.open("", "Help","width=300, height=600, scrollbars=yes,resizable=yes, left=80, top=80");    	
        
        // Header, horizontal line, and beginning of list
        myWindow.document.write("<head>");
        myWindow.document.write("<title>Help</title>");
        myWindow.document.write("</head>");
        myWindow.document.write("<div>");
        myWindow.document.write("<div><h1 style='color:red'>* HELP * </h1></div>");
        myWindow.document.write("<hr>");
        myWindow.document.write("<div> <h2><span style='color:MediumSeaGreen'>Buttons Purpose</span></h2></div>");
        myWindow.document.write("<div>");
        myWindow.document.write("<ul style='list-style-type:circle'>");
        
        //Save button description
        myWindow.document.write("<li>\n <h3 style='color:DodgerBlue'>Save.</h3>");
        myWindow.document.write("<div>Press the <b>Save</b> button to save a record to the SQL database. When clicked, a prompt will be given stating <span style='color:blue'>RECORD ADDED</span>.<br><br>Otherwise, if the record has already been saved previously it will give a prompt stating <span style='color:red'>RECORD ALREADY EXISTS</span>.</div><br></li>");
        
        //Find button description
        myWindow.document.write("<li>\n <h3 style='color:DodgerBlue'>Find.</h3>");
        myWindow.document.write("<div>Press the <b>Find</b> button to find a record using Telephone, which is the primary key.</div><br></li>");
        myWindow.document.write("<div>If the record exists, it will display <span style='color:blue'>RECORD FOUND</span>.<br><br>If the record does not exist, it will display <span style='color:red'>RECORD NOT FOUND</span>.</div>");

        //Modify button description
        myWindow.document.write("<li>\n <h3 style='color:DodgerBlue'>Modify.</h3>");
        myWindow.document.write("<div>Press the <b>Modify</b> button to modify an already existing record.</div><br></li>");
        myWindow.document.write("<div>Steps to modify a record:</div>");
        myWindow.document.write("<ol class='popup-list' type='1'>");
        myWindow.document.write("<li>Enter the Telephone (primary key).</li>");
        myWindow.document.write("<li>Press the <b>Find</b> button to search and find the record.</li>");
        myWindow.document.write("<li>Once the record is found, change the data.<br><em>NOTE: You can <b>NOT</b> modify the primary key.</em></li>");
        myWindow.document.write("<li>Press the <b>Modify</b> button to store the modified data.</li>");
        myWindow.document.write("</ol>");
        myWindow.document.write("<div><br> If done correctly it will state <span style='color:blue'>RECORD MODIFIED</span><br><br>Otherwise it will state <span style='color:red'>RECORD CAN NOT BE MODIFIED, FIND IT FIRST</span></div>");
        
        //Save button description
        myWindow.document.write("<li><h3 style='color:DodgerBlue'>Delete.</h3>");
        myWindow.document.write("<div>Press the <b>Delete</b> button to delete a record. You must find the record <b>BEFORE</b> attempting to delete.<br><br>If done correctly it will state <span style=\"color: red;\">RECORD DELETED</span><br><br>Otherwise, it will state <span style=\"color: red;\">RECORD CAN NOT BE DELETED, IT DOES NOT EXIST</span></div><br></li>");
        
        //Clear Screen button description
        myWindow.document.write("<li>\n <h3 style='color:DodgerBlue'>Clear Screen.</h3>");
        myWindow.document.write("<div>Press the <b>Clear</b> button to clear the data from all fields on the frontend.</div><br></li>");
        
        //Contact_me button description
        myWindow.document.write("<li>\n <h3 style='color:DodgerBlue'>Contact_me.</h3>");
        myWindow.document.write("<div>Press the <b>Contact_me</b> button to be linked to a page where you can contact me for further questions.</div><br></li>");
        
        //Help button description
        myWindow.document.write("<li><h3 style='color:DodgerBlue'>Help.</h3>");
        myWindow.document.write("<div>Press the <b>Help</b> button to discover the purpose and functionality of the buttons.</div><br></li>");
        
        //About button description
        myWindow.document.write("<li>\n <h3 style='color:DodgerBlue'>About.</h3>");
        myWindow.document.write("<div>Press the <b>About</b> button to be linked to a page where you can learn more about the purpose of the website and a background of myself.</div><br></li>");
        
        myWindow.document.write("</ul>");
        myWindow.document.write("</div>");

}


</script>



</body>
</head>
</html>