<!-- ***********************************************************************************
  Page Name  : Modify Button
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Modifys data from SQL Server

  Due Date   : 03/16/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<!DOCTYPE html>   <!-- declaration used in HTML 5. Tells browsers that this is HTML 5 -->

<html>

  <body>
    
    <!--h3>this is modify.phd</h3-->
        
    <?php
        
       $found = $_POST['found']; 
               
/*     
       echo "modify  found = [" . $found . "]<br>";
        
       echo $Telephone."<br>"; 
       echo $FirstName."<br>";  
       echo $LastName."<br>";  
       echo $Email."<br>";  
       echo $Age."<br>";  
       echo $Gender."<br>";  
       echo $IT."<br>";  
       echo $CS."<br>";  
       echo $Robotics."<br>";  
       echo $Engineering."<br>";  
       echo $Others."<br>";  
       echo $SpecialNeeds."<br>";  
             
       echo "<br>modify found = [" . $found . "]";
  */           
          
       if (  ( strlen(trim($found)) > 0 ) && ($found == $Telephone) )
       {               
                  
          $query = "UPDATE customers 
                    SET Email         =  '$Email',
                        LastName      =  '$LastName',
                        FirstName     =  '$FirstName', 
                        Address       =  '$Address',
                        City          =  '$City',
                        State         =  '$State',
                        Country       =  '$Country',
                        Zip           =  '$Zip',
                        Comments      =  '$Comments',
                        Age           =  '$Age',
                        Genre         =  '$Genre',
                        Singleplayer  =  '$Singleplayer',
                        MMO           =  '$MMO',
                        SplitScreen   =  '$SplitScreen',
                        CoOp          =  '$CoOp'
                                 
                   WHERE Telephone = '$Telephone'";
                       
          $sql = mysqli_query( $connection,$query );
                                              
          if ($sql)
          {
             $message ="<span style=\"color: blue;\">RECORD $Telephone MODIFIED</span><br\>";
          }   
          else
          {
             //echo "Problem updating record. MySQL Error: " . mysqli_error($connection);
             $message ="<span style=\"color: red;\">RECORD $Telephone CAN NOT BE MODIFIED, FIND IT FIRST</span><br\>";
          }
             
       }   
       else
       {
          //echo "Find the record before modifying :" . mysqli_error($connection);
          $message ="<span style=\"color: red;\">RECORD $Telephone CAN NOT BE MODIFIED, FIND IT FIRST</span><br\>";
       }
           
    ?>
            
  </body>
                
</html>