<!-- ***********************************************************************************
  Page Name  : Program 4 Page 
  Author     : Hytham Jurdi 
  Your URL   : ocelot-aul.fiu/~hjurd001
  Course     : CGS 4854 Online
  Program #  : Assignment #3
  Purpose    : Program 4 Page that includes 3 php files, contains a table with text inputs, radio buttons, submit buttons, and passes data to controller.

  Due Date   : 04/13/2023 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ Hytham Jurdi }..........
******************************************************************************* -->
<!DOCTYPE html>
<html>

  <head>
<title>JurdiHythamProgram4</title>
</head>

<body>
<header>
   
<head>

    <?php include ( 'Jurdi_header.php' ); ?>

  <script>

      function currentTime() 
      {
         var today   = new Date();
         var hour    = today.getHours();
         var minutes = today.getMinutes();
         var sec     = today.getSeconds();
      
         minutes = checkTime(minutes);
         sec     = checkTime(sec);
         
         document.getElementById('txt').innerHTML = "Current Time : "+hour+":"+minutes+":"+sec;
      
         var t = setTimeout(function(){currentTime()},500);
              
      }


      function checkTime(i) 
      {
         if (i<10) {i = "0" + i};  // add zero in front of numbers < 10
         return i;
      }

  </script>
  </head>
    <body onload="currentTime()">
    <center>
      <table style="width: 100%; margin: 0px auto; padding-right: 0%;">
        <tr>
          <td align="left">
            <script>
              loggedInTime();

              var temp1;

              function loggedInTime(temp)
              {
                var tiempo = new Date();
                var temp2 = "Logged in: " + tiempo;
                temp1 = temp2;
                document.write(temp2);
              }

              currentTime();
            </script>
          </td>
          <td id="txt" style="text-align: right;"></td>
        </tr>
      </table>
    </center>
    <td>&nbsp;</td> <!--Empty Row-->
    <center><b><font color="red">Program 4</font></b></center>
      <style>
    .tooltip 
    {
      position: relative;
      display: inline-block;

    }

    .tooltip .tooltiptext 
    {
      visibility: hidden;
      width: 120px;
      background-color: cyan;
      color: #fff;
      text-align: center;
      border-radius: 6px;
      padding: 5px 0;
      position: absolute;
      z-index: 1;
      bottom: 125%;
      left: 50%;
      margin-left: -60px;
      opacity: 0;
      transition: opacity 1s;
    }


    .tooltip .tooltiptext .tooltip-left 
    {
      top: -5px;
      bottom:auto;
      right: 128%;  
    }



    .tooltip .tooltiptext::after 
    {
      content: "";
      position: absolute;
      top: 100%;
      left: 50%;
      margin-left: -5px;
      border-width: 5px;
      border-style: solid;
      border-color: red transparent transparent transparent; /*arrow*/
    }

    .tooltip:hover .tooltiptext 
    {
      visibility: visible;
      opacity: 1;
    }

  </style>
</body>
   
   <td>&nbsp;</td> <!--Empty Row-->
    <?php include ( 'mainMenu.php' ); ?>
    <td>&nbsp;</td> <!--Empty Row-->
    
 
      <form method="post" action="Controller4.php">
        <table style="width: 50%; margin: 0px auto; padding-right: 10%;">
          <!--  text type input  -->
          <tr>
        <td style="width: 5%; text-align: right;" >
           <div class="tooltip">Telephone &nbsp; 
             <span class="tooltiptext"><font color="black">REQUIRED</font></span>
           </div>
        </td>
            <td style="width: 20%;">
              <input type="text" name="Telephone" placeholder="Telephone" value="<?php echo $Telephone ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">Email&nbsp;
              <span class="tooltiptext"><font color="black">Enter Email</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input id="birth" type="text" name="Email" placeholder="Email" value="<?php echo $Email ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">Last Name&nbsp;
                <span class="tooltiptext"><font color="black">Enter Last Name</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input type="text" name="LastName" placeholder="Last Name" value="<?php echo $LastName ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">First Name&nbsp;
                <span class="tooltiptext"><font color="black">Enter First Name</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input type="text" name="FirstName" placeholder="First Name" value="<?php echo $FirstName ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">Address&nbsp;
                <span class="tooltiptext"><font color="black">Enter Address</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input type="text" name="Address" placeholder="Adress" value="<?php echo $Address ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">City&nbsp;
                <span class="tooltiptext"><font color="black">Enter City</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input type="text" name="City" placeholder="City" value="<?php echo $City ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">State&nbsp;
                <span class="tooltiptext"><font color="black">Enter State</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input type="text" name="State" placeholder="State" value="<?php echo $State ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">Country&nbsp;
                <span class="tooltiptext"><font color="black">Enter Country</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input type="text" name="Country" placeholder="Country" value="<?php echo $Country ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">Zip&nbsp;
                <span class="tooltiptext"><font color="black">Enter Zip</font></span>
              </div>
            </td>
            <td style="width: 20%;">
              <input type="text" name="Zip" placeholder="Zip" value="<?php echo $Zip ?>" style="width: 100%;">
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td> <!--Empty Row-->
          </tr>
          <!--  textarea box  -->
          <tr>
            <td style="width: 7%; text-align:right;">
              <div class="tooltip">Comments&nbsp;
                <span class="tooltiptext"><font color="black">Enter Any Comments</font></span>
              </div>
            </td>
            <td style="width: 20%;"> 
            <textarea name="Comments" placeholder="Comments" style="width: 99%;" rows="5" cols="35"><?php echo $Comments;?></textarea></td>
          </tr>
          <td>&nbsp;</td> <!--Empty Row-->
          <!--  dropdown boxes -->
          <tr>
            <td style="width: 5%; text-align: right;">
              <div class="tooltip">Age&nbsp;
                <span class="tooltiptext"><font color="black">Select Your Age Range</font></span>
              </div>
            </td>
            <td style="width: 20%; text-align: left;">
              <select name="Age" style="width: 100%" size="1" ;>
                <option value="Under_20" <?php if ($Age == "Under_20") echo selected ?>>Under 20 </option>
                <option value="20-30" <?php if ($Age == "20-30")    echo selected ?>>20-30 </option>
                <option value="31-40" <?php if ($Age == "31-40")    echo selected ?>>31-40 </option>
                <option value="41-50" <?php if ($Age == "41-50")    echo selected ?>>41-50 </option>
                <option value="51-60" <?php if ($Age == "51-60")    echo selected ?>>51-60 </option>
                <option value="Above_60" <?php if ($Age == "Above_60") echo selected ?>>Above 60 </option>
              </select>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td> <!--Empty Row-->
          </tr>
          <!--Radio Buttons-->
          <tr>
            <td style="width: 7%; text-align: right;">
              <div class="tooltip">Game Genre&nbsp;
                <span class="tooltiptext"><font color="black">Select Preferred Genre</font></span>
              </div>
            </td>
            <td style="width: 20%; text-align: left;">
              <table style="width: 100%;">
                <tr>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "FPS")   echo "checked"; ?> name="Genre" value="FPS" checked> FPS&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Adventure") echo "checked"; ?> name="Genre" value="Adventure"> Adventure&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Mystery")   echo "checked"; ?> name="Genre" value="Mystery" checked> Mystery&nbsp;</td>
                  </td>
                  <td style="width: 20%;">
                    <input type="radio" <?php if ($Genre == "Horror") echo "checked"; ?> name="Genre" value="Horror"> Horror&nbsp;</td>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <!--Checkboxes-->
          <tr>
            <td style="width: 7%; text-align: right">
              <div class="tooltip">Game Type&nbsp;
                <span class="tooltiptext"><font color="black">Select Preferred Game Type(s)</font></span>
              </div>
            </td>
            <td style="width: 20%; ">
              <table style="width: 100%;">
                <tr>
                  <td style="width: 20%;">
                    <input type="checkbox" name="Singleplayer" 
                    <?php if ($Singleplayer == "Singleplayer") echo checked;?> value="Singleplayer"> Singleplayer&nbsp;&nbsp;
                  </td>
                  <td style="width: 20%;">
                    <input type="checkbox" name="MMO" 
                    <?php if ($MMO == "MMO") echo checked;?> value="MMO"> MMO&nbsp;&nbsp;
                  </td>
                  <td style="width: 20%;">
                    <input type="checkbox" name="SplitScreen" 
                    <?php if ($SplitScreen == "SplitScreen") echo checked;?> value="SplitScreen"> Split Screen&nbsp;&nbsp;
                  </td>
                  <td style="width: 20%;">
                    <input type="checkbox" name="CoOp" 
                    <?php if ($CoOp == "CoOp") echo checked;?> value="CoOp"> Co-Op
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
          <td>&nbsp;</td> <!--Empty Row-->
          </tr>
          <table style="width:100%;">
            <tr>
              <td style="text-align:center;"><?php echo $message ?></td>
            </tr>
          </table>
          <td>&nbsp;</td> <!--Empty Row-->
          <table style="width:100%;">
            <tr>
              <td style="text-align:center;">
                <input type="submit" name="Save" value="Save">&nbsp; 
                <input type="submit" name="Find" value="Find">&nbsp; 
                <input type="submit" name="Modify" value="Modify">&nbsp; 
                <input type="submit" name="Delete" value="Delete">&nbsp; 
                <input type="submit" name="Clear" value="Clear Screen">&nbsp; 
                <input type="submit" name="submit" value="Contact_Me">&nbsp; 
                <input type="submit" name="help" value="Help">&nbsp; 
                <input type="submit" name="about" value="About">
                <input type="hidden" name="found" value="<?php echo $found ?>">
              </td>
            </tr>
          </table>
          <td>&nbsp;</td> <!--Empty Row-->
          <?php include ( 'mainMenu.php' ); ?>
          <td>&nbsp;</td> <!--Empty Row-->
          <center>Hytham Jurdi</center>
      </form>
    </header> 
    
  </body>
</html>